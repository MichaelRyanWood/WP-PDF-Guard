/**
 * WP-PDF-Guard Frontend JavaScript
 *
 * Reserved for future use (e.g., Gutenberg block registration).
 */
